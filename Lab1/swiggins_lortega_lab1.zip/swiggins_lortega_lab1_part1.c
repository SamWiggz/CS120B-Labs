#include "rims.h"

/*	Partner(s) Name & E-mail: Samuel Wiggins (swigg002@ucr.edu) Leo Ortega (lorte007@ucr.edu)
 *	Lab Section: 021
 *	Assignment: Lab #1  Exercise #1 
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

void main() {
   while (1) {
      B0 = A0;
      B1 = A1;
      B2 = A2;
      B3 = A3;
      B4 = A4;
      B5 = A5;
      B6 = A6;
      B7 = A7;
   }
}
